/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var app = {
    // Application Constructor
    initialize: function() {
        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
    },

    // deviceready Event Handler
    //
    // Bind any cordova events here. Common events are:
    // 'pause', 'resume', etc.
    onDeviceReady: function() {
        //this.receivedEvent('deviceready');
        
        document.getElementById("devManuf").innerHTML=device.manufacturer;
        document.getElementById("devDet").innerHTML="Device model: " + device.model + "\n" + "Device platform: " + device.platform + "\n" + "Device UUID: " + device.uuid + "\n" + "Device version: " + device.version; 
        //document.getElementById("selectImage").addEventListener("click",this.cameraGetPicture);
        //document.getElementById("selectImage1").addEventListener("click",this.cameraTakePicture);
        document.getElementById("giveMessage").addEventListener("click", this.selectOption);
    },
    
    // Update DOM on a Received Event
    // receivedEvent: function(id) {
    //     var parentElement = document.getElementById(id);
    //     var listeningElement = parentElement.querySelector('.listening');
    //     var receivedElement = parentElement.querySelector('.received');

    //     listeningElement.setAttribute('style', 'display:none;');
    //     receivedElement.setAttribute('style', 'display:block;');

    //     console.log('Received Event: ' + id);
    // }
    // ,
     selectOption: function() {
            var message = "Choose image from";
            var title = "...";
            var buttonLabels = "Camera,Gallery";
            navigator.notification.confirm(message, confirmCallback, title, buttonLabels);
         
    //         function confirmCallback(buttonIndex) {
    //            if(buttonIndex == 1){
    //                cameraTakePicture();
    //            }
    //            else if(buttonIndex == 2){
    //                cameraGetPicture();
    //            }
    //         }
             
          }
    ,
    cameraGetPicture: function() {
        navigator.camera.getPicture(onSuccess, onFail, { quality: 50,
           destinationType: Camera.DestinationType.FILE_URI,
           sourceType: Camera.PictureSourceType.PHOTOLIBRARY
        });
     
        function onSuccess(imageURI) {
           var image = document.getElementById('dp');
           image.src = imageURI;
        }
     
        function onFail(message) {
           alert('Failed because: ' + message);
        }
     
     }
,
    cameraTakePicture: function() { 
        navigator.camera.getPicture(onSuccess, onFail, {  
           quality: 50, 
           destinationType: Camera.DestinationType.DATA_URL 
        });  
        
        function onSuccess(imageData) { 
           var image = document.getElementById('dp'); 
           image.src = "data:image/jpeg;base64," + imageData; 
        }  
        
        function onFail(message) { 
           alert('Failed because: ' + message); 
        } 
     }

};


function confirmCallback(buttonIndex) {
    if(buttonIndex == 1){
        app.cameraTakePicture();
    }
    else if(buttonIndex == 2){
        app.cameraGetPicture();
    }
 }
  

app.initialize();